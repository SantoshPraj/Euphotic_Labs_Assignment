// src/Dishes.js
import React, { useEffect, useState } from 'react';
import axios from 'axios';

const Dishes = () => {
    const [dishes, setDishes] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchDishes = async () => {
            try {
                const response = await axios.get('http://localhost:5000/dishes');
                setDishes(response.data);
                setLoading(false);
            } catch (err) {
                setError(err.message);
                setLoading(false);
            }
        };

        fetchDishes();
    }, []);

    if (loading) {
        return <p>Loading...</p>;
    }

    if (error) {
        return <p>Error: {error}</p>;
    }

    return (
        <div>
            <h1>Dishes</h1>
            <ul>
                {dishes.map((dish) => (
                    <li key={dish.dishId}>
                        <h2>{dish.dishName}</h2>
                        <img src={dish.imageUrl} alt={dish.dishName} width="200" />
                        <p>{dish.isPublished ? 'Published' : 'Not Published'}</p>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default Dishes;
