// src/App.js
import React from 'react';
import './App.css';
import Dishes from './components/Dishes';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>Dish List</h1>
      </header>
      <main>
        <Dishes />
      </main>
    </div>
  );
}

export default App;
