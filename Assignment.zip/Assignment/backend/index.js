// server.js
const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const Dish = require('./models/dishModel');
const cors = require('cors');


const app = express();
const port = process.env.PORT || 5000;

// Middleware
app.use(bodyParser.json());


app.use(cors({
    origin: 'http://localhost:5173', // Adjust this to match your React app's URL
    credentials: true
}));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));



// MongoDB connection
const connectToMongoDB = async () => {
    try {
        await mongoose.connect('mongodb://localhost:27017/dishesDB', {
            useNewUrlParser: true,
            useUnifiedTopology: true
        });
        console.log('Connected to MongoDB');
    } catch (err) {
        console.error('Could not connect to MongoDB...', err);
    }
};

connectToMongoDB();

// Routes
app.post('/dishes', async (req, res) => {
    const dishes = req.body;
    const savedDishes = [];

    try {
        for (const dishData of dishes) {
            const newDish = new Dish(dishData);
            const savedDish = await newDish.save();
            savedDishes.push(savedDish);
        }
        res.status(201).send(savedDishes);
    } catch (err) {
        res.status(400).send(err);
    }
});

app.get('/dishes', async (req, res) => {
    try {
        const dishes = await Dish.find();
        res.status(200).send(dishes);
    } catch (err) {
        res.status(400).send(err);
    }
});

app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});
